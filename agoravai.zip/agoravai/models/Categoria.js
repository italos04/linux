const mongoose = require("mongoose")
const Schema = mongoose.Schema;

const Categoria = new Schema({
    matricula:{
        type: Number,
    },
    servico:{
        type: String,
    },
    usuario:{
        type: String,
    },
    nome:{
        type: String,
        default:"Opcional"
    },
    outro:{
        type: String,
    },
    date:{
        type: Date,
        default: Date.now()
    }
})

mongoose.model("categorias", Categoria)