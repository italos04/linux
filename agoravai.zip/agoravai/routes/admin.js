const express = require('express')
const router = express.Router()
const mongoose = require('mongoose')
require("../models/Categoria")
const Categoria = mongoose.model("categorias")

router.get('/categorias', (req, res) =>{
    res.render("admin/categorias")
})

router.get('/atendimentos', (req, res)=>{
    Categoria.find().sort({date: 'desc'}).then((categorias)=>{
        res.render("admin/atendimentos", {categorias: categorias})
    }).catch((err)=>{
        req.flash("error_msg", "erro")
        res.redirect("/admin")
    })
})
router.get('/categorias/alu', (req, res) =>{
    res.render("admin/addnew")
})

router.post("/categorias/deletar", (req, res)=>{
    Categoria.remove({_id: req.body.id}).then(()=>{
        req.flash("success", "Atendimento removido!")
        res.redirect("/admin/atendimentos")
    }).catch((err)=>{
        req.flash("error_msg", "Erro ao remover")
        res.redirect("/admin/categorias")
    })
})
router.post('/categorias/new', (req, res)=>{
        const novaCategoria = {
            matricula:req.body.matri,
            servico:req.body.servi,
            nome:req.body.nome,
            outro:req.body.outro,
            usuario:req.body.usuario
        }
    
        new Categoria(novaCategoria).save().then(() =>{
            req.flash("success_msg", "retire a senha")
            res.redirect("../../")
        }).catch((err)=>{
            req.flash("error_msg", "tente novamente")
            console.log("erro"+err)
        })
    }
)
module.exports = router