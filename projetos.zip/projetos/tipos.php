<?php
$idade = 21;
echo "Olá mundo!\n" ;
echo "Eu tenho $idade anos";
?>