<?php

$var = -1;

if($var <=5){
    echo "voce esta de madrugada";
}elseif($var <=12){
    echo "voce esta de manha";
}elseif($var <=18){
    echo "voce esta de tarde";
}else{
    echo "voce esta de noite";
}