<?php
class Produto {
    public $descricao;
    public $estoque;
    public $preco;
    public $codProduto;
    public $marca;
    public $corEmbalagem;
    public $prazoValidade;
}

$p1 = new Produto;
$p1->descricao = 'chocolate';
$p1->estoque = 10;
$p1->preco = 7;
$p1->codProduto = 0002;
$p1->marca = 'avom';
$p1->corEmbalagem = 'azul';
$p1->prazoValidade = '10/08/2008';

$p2 = new Produto;
$p2->descricao = 'café';
$p2->estoque = 20;
$p2->preco = 4;
$p2->codProduto = 02302;
$p2->marca = 'jequit';
$p2->corEmbalagem = 'red';
$p2->prazoValidade = '25/12/2018';


$p3 = new Produto;
$p3->descricao = 'Bisnaguinhas';
$p3->estoque = 30;
$p3->preco = 4.50;
$p3->codProduto = 001;
$p3->marca = 'Seven Boys';
$p3->corEmbalagem = 'Azul';
$p3->prazoValidade = '10/10/2018';


$p4 = new Produto;
$p4->descricao = 'Nutella';
$p4->estoque = 45;
$p4->preco = 9.50;
$p4->codProduto = 002;
$p4->marca = 'NUtella';
$p4->corEmbalagem = 'Marrom';
$p4->prazoValidade = '10/11/2018';


$p5 = new Produto;
$p5->descricao = 'Rola';
$p5->estoque = 30;
$p5->preco = 4.50;
$p5->codProduto = 003;
$p5->marca = 'molenga';
$p5->corEmbalagem = 'verde';
$p5->prazoValidade = '10/12/2018';


var_dump($p1);
echo '<br>';
echo '<br>';
var_dump($p2);
echo '<br>';
echo '<br>';
var_dump($p3);
echo '<br>';
echo '<br>';
var_dump($p4);
echo '<br>';
echo '<br>';
var_dump($p5);
