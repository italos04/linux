<?php
class Produto {
    public $descricao;
    public $estoque;
    public $preco;
    public $codProduto;
    public $marca;
    public $corEmbalagem;
    public $dataFabricacao;
    public $prazoValidade;
    public $pesoEmbalagem;
    public $pesoProduto;
        public function aumentarEstoque($unidades){
            if(is_numeric($unidades) AND $unidades >= 0){
                $this->estoque += $unidades;
            }
        }
        public function diminuirEstoque($unidades){
            if(is_numeric($unidades) AND $unidades >= 0){
                $this->estoque -= $unidades;
            }
        }
        public function reajustarPreco($percentual){
            if(is_numeric($percentual) AND $percentual >= 0){
                $this->preco *= (1 +($percentual/100));
            }
        }
    }

    $p1 = new Produto;

    $p1->descricao = 'chocolate';
    $p1->estoque = 10;
    $p1->preco = 8;
    $p1->codProduto = 0002;
    $p1->marca = 'avom';
    $p1->corEmbalagem = 'azul';
    $p1->dataFabricacao = '11/12/2002';
    $p1->prazoValidade = '10/08/2008';
    $p1->pesoEmbalagem = '12kg';
    $p1->pesoProduto = '10kg';

    print "o estoque de {$p1->descricao} é {$p1->estoque} <br>";
    print "o preço de {$p1->descricao} é {$p1->preco} <br>";
    print "o codigo de {$p1->descricao} é {$p1->codProduto} <br>";
    print "o marca de {$p1->descricao} é {$p1->marca} <br>";
    print "o cor de {$p1->descricao} é {$p1->corEmbalagem} <br>";
    print "o data de fabricação de {$p1->descricao} é {$p1->dataFabricacao} <br>";
    print "o prazo de validade de {$p1->descricao} é {$p1->prazoValidade} <br>";
    print "o peso embalagem de {$p1->descricao} é {$p1->pesoEmbalagem} <br>";
    print "o peso produto de {$p1->descricao} é {$p1->pesoProduto} <br>";  
    $p1->aumentarEstoque(10);
    $p1->diminuirEstoque(5);
    $p1->reajustarPreco(50);
    print "o estoque de {$p1->descricao} é {$p1->estoque} <br>";
    print "o preço de {$p1->descricao} é {$p1->preco} <br>";
    echo '<br>';
    $p2 = new Produto;

    
    $p2->descricao = 'leite';
    $p2->estoque = 10;
    $p2->preco = 8;
    $p2->codProduto = 0202;
    $p2->marca = 'aula';
    $p2->corEmbalagem = 'rosa';
    $p2->dataFabricacao = '11/12/2022';
    $p2->prazoValidade = '10/08/2028';
    $p2->pesoEmbalagem = '12kg';
    $p2->pesoProduto = '10kg';

    print "o estoque de {$p2->descricao} é {$p2->estoque} <br>";
    print "o preço de {$p2->descricao} é {$p2->preco} <br>";
    print "o codigo de {$p2->descricao} é {$p2->codProduto} <br>";
    print "a marca de {$p2->descricao} é {$p2->marca} <br>";
    print "a cor de {$p2->descricao} é {$p2->corEmbalagem} <br>";
    print "a data de fabricação de {$p2->descricao} é {$p2->dataFabricacao} <br>";
    print "o prazo de validade de {$p2->descricao} é {$p2->prazoValidade} <br>";
    print "o peso da embalagem de {$p2->descricao} é {$p2->pesoEmbalagem} <br>";
    print "o peso do produto de {$p2->descricao} é {$p2->pesoProduto} <br>";    
    $p2->aumentarEstoque(10);
    $p2->diminuirEstoque(5);
    $p2->reajustarPreco(50);
    print "o estoque de {$p2->descricao} é {$p2->estoque} <br>";
    print "o preço de {$p2->descricao} é {$p2->preco} <br>";
    echo '<br>';
    $p3 = new Produto;

    $p3->descricao = 'cafe';
    $p3->estoque = 13;
    $p3->preco = 9;
    $p3->codProduto = 4302;
    $p3->marca = 'belem';
    $p3->corEmbalagem = 'roxo';
    $p3->dataFabricacao = '11/12/2042';
    $p3->prazoValidade = '10/08/2068';
    $p3->pesoEmbalagem = '12kg';
    $p3->pesoProduto = '10kg';

    print "o estoque de {$p3->descricao} é {$p3->estoque} <br>";
    print "o preço de {$p3->descricao} é {$p3->preco} <br>";
    print "o codigo de {$p2->descricao} é {$p3->codProduto} <br>";
    print "a marca de {$p2->descricao} é {$p3->marca} <br>";
    print "a cor da embalagem de {$p3->descricao} é {$p3->corEmbalagem} <br>";
    print "a data de fabricação de {$p3->descricao} é {$p3->dataFabricacao} <br>";
    print "o estoque de {$p3->descricao} é {$p3->prazoValidade} <br>";
    print "o preço de {$p3->descricao} é {$p3->pesoEmbalagem} <br>";
    print "o estoque de {$p3->descricao} é {$p3->pesoProduto} <br>";  
    $p3->aumentarEstoque(10);
    $p3->diminuirEstoque(5);
    $p3->reajustarPreco(50);
    print "o estoque de {$p3->descricao} é {$p3->estoque} <br>";
    print "o preço de {$p3->descricao} é {$p3->preco} <br>";
    echo '<br>';
    $p4 = new Produto;

    $p4->descricao = 'suco';
    $p4->estoque = 12;
    $p4->preco = 78;
    $p4->codProduto = 7802;
    $p4->marca = 'ject';
    $p4->corEmbalagem = 'rosa';
    $p4->dataFabricacao = '11/12/2302';
    $p4->prazoValidade = '10/08/2308';
    $p4->pesoEmbalagem = '12kg';
    $p4->pesoProduto = '10kg';

    print "o estoque de {$p4->descricao} é {$p4->estoque} <br>";
    print "o preço de {$p4->descricao} é {$p4->preco} <br>";
    print "o codigo de {$p4->descricao} é {$p4->codProduto} <br>";
    print "a marca de {$p4->descricao} é {$p4->marca} <br>";
    print "a cor de {$p4->descricao} é {$p4->corEmbalagem} <br>";
    print "a data de fabricação de {$p4->descricao} é {$p4->dataFabricacao} <br>";
    print "o prazo de validade de {$p4->descricao} é {$p4->prazoValidade} <br>";
    print "o peso da embalagem de {$p4->descricao} é {$p4->pesoEmbalagem} <br>";
    print "o peso do produto de {$p4->descricao} é {$p4->pesoProduto} <br>";  
    
    $p4->aumentarEstoque(10);
    $p4->diminuirEstoque(5);
    $p4->reajustarPreco(50);
    print "o estoque de {$p4->descricao} é {$p4->estoque} <br>";
    print "o preço de {$p4->descricao} é {$p4->preco} <br>";
    echo '<br>';