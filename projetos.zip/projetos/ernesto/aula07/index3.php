<?php
class Produto
{
    private $descricao;
    private $estoque;
    private $preco;
    public $codigo_produto;
    public $marca;
    public $cor_embalagem;
    public $prazo_validade;
    public $peso_embalagem;
    public $peso_produto;
    public function numero_dias_consumo($data_validade){ 
        $data_atual = date_create(); 
        $validade = date_create($data_validade);   
        if($data_atual > $validade){
            return $this->status = 'Vencido a '.date_diff($data_atual, $validade)->days.' dias';
        } 
        else {
            return $this->status = 'Nao venceu ainda, falta '.date_diff($data_atual, $validade)->days.' dias';
        }
    }

    public function alter_descricao_produto($nova_descricao){
        return $this->descricao = $nova_descricao;
    }

    public function peso_total_embalagem($produto){
        return $this->produto = $produto->peso_produto + $produto->peso_embalagem;
    }

    public function setDescricao($descricao){
        if(is_string($descricao)){
            $this->descricao = $descricao;
        }
    }

    public function getDescricao(){
        return $this->descricao;
    }

    public function setEstoque($estoque){
        if(is_numeric($estoque)){
            $this->estoque = $estoque;
        }
    }

    public function getEstoque(){
        return $this->estoque;
    }

    public function setPreco($preco){
        $this->preco = $preco;
    }

    public function getPreco(){
        return $this->preco;
    }
}

$p1 = new Produto;
$p1->setDescricao('Chocolate');
$p1->setEstoque(30);
$p1->setPreco(9.50);
$p1->codigo_produto = 001;
$p1->marca = 'Seven Boys';
$p1->cor_embalagem = 'Azul';
$p1->prazo_validade = '10/10/2018';
$p1->peso_embalagem = 30;
$p1->peso_produto = 20;
$p1->alter_descricao_produto('Nova descricao');
$p1->peso_total_embalagem($p1->prazo_validade);
$p1->numero_dias_consumo('2019/09/10');

var_dump($p1);