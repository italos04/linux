<?php

    $valor = 0;

if($valor > 0){
    echo "valor positivo";
}elseif($valor < 0){
    $resultado = "valor negativo";
}else{
    $resultado = "igual a zero";
}
echo $resultado;