<?php
$num = 0;

$array_meses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

$mes_selecionado = $array_meses[$num-1];

if(isset($mes_selecionado)){
    echo $mes_selecionado;
}else{
    echo "mes invalido";
}
