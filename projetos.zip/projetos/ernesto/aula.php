<?php

$array_aluno = [ 6, 6, 6];

$notaTotal = $array_aluno[0] + $array_aluno[1] + $array_aluno[2];

$nota_media = $notaTotal/count($array_aluno);

echo $nota_media;

if($nota_media >= 6){
    echo "<br>Aprovado";
} else {
    echo "<br>Reprovado";
}
?>