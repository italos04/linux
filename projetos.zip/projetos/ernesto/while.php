<?php

$valor = 1;

while($valor >= 1 || $valor / 2 % !0 && $valor < 100){
    echo "$valor -";
    $valor=$valor+2;
}
echo "fim";