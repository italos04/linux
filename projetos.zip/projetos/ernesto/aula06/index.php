<?php
require "ContaCorrente.php";
$contaItalo = new ContaCorrente("italo", "4575-2", "5558", 5555);

echo $contaItalo->titular = "silva";
echo $contaItalo->saldo;
var_dump($contaItalo);