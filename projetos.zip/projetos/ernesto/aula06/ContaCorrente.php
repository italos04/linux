<?php
class ContaCorrente{
    private $titular;
    private $agencia;
    private $numero;
    private $saldo;
    
    public function __construct($titular, $agencia, $numero, $saldo){
        $this->titular = $titular;
        $this->agencia = $agencia;
        $this->numero = $numero;
        $this->saldo = $saldo;
    }
    public function sacar ($valor){
        $this->saldo = $this->saldo - $valor;
    }
    public function depositar ($valor){
        $this->saldo = $this->saldo + $valor;
    }
    public function __get($atributo){
        return $this->$atributo;
    }
    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }
}