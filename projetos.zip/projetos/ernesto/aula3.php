<?php
$idade = [13, 19, 15, 16, 17, 18];
$maioridade = 0;
$menoridade = 0;

for($i = 0; $i<=count($idade);$i++){
    if($idade[$i]>=18){
        $maioridade++;
    }else{
        $menoridade++;
    }
}

echo "apenas $maioridade é maior de idade";