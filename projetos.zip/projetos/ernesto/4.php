<?php
$valor = 90;

for($i=0; $i <= 10; $i++){
    $var1 = $valor * $i;
    echo "$valor x $i = $var1";
    echo "<br/>"; 
}