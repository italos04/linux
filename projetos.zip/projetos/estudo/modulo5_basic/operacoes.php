<?php
$var1 = 11;
$var2 = 11;

if($var1 < $var2 || $var2 == $var1){
    echo 'menor ou igual';
}else{
    echo 'maior';
}
