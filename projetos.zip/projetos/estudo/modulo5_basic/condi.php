<?php
$var1 = 10 + 5;; 
$var2 = '10 + 5';

if($var1 == $var2){
    echo "oi lindo";
}else{
    echo 'falos';
}