<?php

/*
//Data e hora Atual
    date_default_timezone_set('America/Sao_Paulo');

    $data = date('d/m/Y H:i:s',time()+(60*10));

    echo $data;
*/

//utilizando include

$titulo= 'test do site';

include('test.php');

?>

<h1>italo foda</h1>    

<?php 
include('test2.php');
?>