<?php
/*
    //Sleep
sleep(3);
echo 'ola';
sleep(2);
echo '<br>';
echo 'italo';
*/
    //Die
$nome = 'talo';

if($nome == 'italo'){
    echo 'acertou';
}else{
    die("faliceu");
}