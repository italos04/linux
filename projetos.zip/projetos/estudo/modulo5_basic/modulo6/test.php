<html>
<header>
<title><?php echo $titulo; ?></title>
</header>
<body>
parte de cima