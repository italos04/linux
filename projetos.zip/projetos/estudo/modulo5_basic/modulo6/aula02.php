<?php
    //array multidimensionais

    $arr = array(array('italo', 'silva', 'pereira'),array(23,24,25));
    echo $arr[1][2];
