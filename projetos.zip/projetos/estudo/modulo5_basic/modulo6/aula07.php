<?php

    $nome = 'italo';
/*
//vazer validação
        switch($nome){
            case 'italo':
            echo 'minha variavel é italo';
            break;
            case 'silva':
            echo 'minha variavel é silva';
            break;
        }
        */
 
//Break para loop for, while, do, foreach e switch
//Continue para loop for, while, do, foreach;
        for($i = 0; $i<10; $i++){
            if($i == 9)
                continue;
            echo $i;
            echo '<hr>';
            
        }
