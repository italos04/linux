<?php
/*
    //funções
    function mostrarnome($nome,$idade){
        echo '<h2>Nome é:<h2>'.$nome;
        echo '<hr>';
        echo "idade: $idade";
    }

    mostrarnome('italo',21);
*/
/*
    function calcular($nu1 =10, $nu2 = 5){
        echo ($nu1+$nu2);
    }

    calcular(35,50);
*/

    function verdade(){
        return true;
    }
    echo $varia = verdade();