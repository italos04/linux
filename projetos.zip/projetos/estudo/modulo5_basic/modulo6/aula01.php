<?php
$arr = array('italo', 'silva', 'pereira', 'antonio');
/*
foreach($arr as $key => $value){
    echo $key;
    echo '=>';
    echo $value;
    echo '<hr>';
}
*/
$total = count($arr);
for($i=0;$i < $total; $i++){
    echo $arr[$i];
    echo '<hr>';
    echo '<br>';
}
