<?php
/*
    $conteudo = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a facilisis diam. 
    Mauris pellentesque auctor dapibus. Etiam rhoncus rutrum velit, id interdum purus rutrum ut. 
    Donec blandit augue metus, vitae gravida dui dictum ut. Etiam lacinia ex nec aliquam iaculis. 
    Phasellus semper turpis eu fringilla lobortis. Aliquam erat volutpat. Sed eu quam neque. Praesent 
    in neque leo. Donec quis ipsum tempor, elementum tellus sed, vulputate quam. Phasellus non pellentesque 
    arcu. Nulla condimentum rhoncus leo eu ornare.';

    //Serve para recortar uma parte da string

    echo substr($conteudo,0,25);

    echo '<br>';
    */
    $nome = 'italo antonio silva pereira';

    $nomes = explode(' ',$nome);

    //print_r($nomes);

    //Serve para juntar um array com um delimitador
    //No caso o espaço.
    $nomes = implode(' ',$nomes);

    //echo $nomes;

    $conteudo = '<h1>Italo</h1>Outra coisa';

    //Strip_tags retira todo o codigo html

    //echo strip_tags($conteudo);


    //htmlentities mostra o codigo html na pagina

    echo htmlentities('<div></div>');

