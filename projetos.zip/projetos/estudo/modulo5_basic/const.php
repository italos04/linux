<?php

define('Nome', 'Italo');
    echo Nome;


    