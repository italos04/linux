<html>
<header>
<title>italo silva</title>
<meta charset="utf-8">
</head>
<body>
<p>
<?php 
echo 'ola mundo!';
echo '<br>';
echo 'italo silva';

?>
</p>

</body>

</html>