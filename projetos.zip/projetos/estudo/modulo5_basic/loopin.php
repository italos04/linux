<?php
/*
for($contador=0;$contador<10;$contador++){
    echo 'ola italo';
    echo '<br>';    
}
//verifica a condição antes de executar
$cont=0;
while($cont<10){
    echo 'italo silva';
    echo '<br>';
    $cont+=1;
}
*/

//executa antes de conferir a condição!
$cont=11;
do{
    echo 'ola mundo';
    echo '<br>';
}while($cont == 10);{

}
