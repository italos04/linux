<?php
    $italo = ['italo', 'silva', 'pereira'];
        echo $italo[2];