<?php
$nome = 'italo silva';
$idade = 25;
$bool = true;

echo 'minha idade é '.$idade;

echo '<br>';

echo 'meu nome é '.$nome;