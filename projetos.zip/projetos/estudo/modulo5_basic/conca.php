<?php

$nome = 'italo';
$idade = 21;

echo "meu nome é $nome e minha idade é $idade";