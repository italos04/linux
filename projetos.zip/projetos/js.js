let card = document.getElementById('card')
card.innerText;
console.log(card.innerHTML)