<?php
    $idade = 19;
    $nome = italo;

    if($idade >=18 and $nome == 'italo'){
        echo "você tem $idade anos.";
        echo "Pode entrar!";
    }
?> 