<?php
$idadeList = [21, 23, 25, 27, 29, 31];
for($i = 0; $i < 7; $i ++){
    echo $idadeList [$i];
}

