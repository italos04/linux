<?php
$idade = 16;
$idadePessoa = 18;
        echo "voce so pode entrar se tiver a partir de 18 anos ou\n";
        echo "se voce tiver 16 anos e estiver acompanhado por um maior de idade<br>";

        if($idade >= 18 || $idade>= 16 && $idadePessoa>= 18 ){
            echo "voce pode entrar!";
    }else{
        echo "nao entre";
    }